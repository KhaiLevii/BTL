<?php 
require("header.php");
?>

<br>
<br>
<!-- slide show -->
<div class="row">
    <div class="col-md-12">
        <div class="carousel slide" id="carousel-916956">
            <ol class="carousel-indicators">
                <li data-slide-to="0" data-target="#carousel-916956">
                </li>
                <li data-slide-to="1" data-target="#carousel-916956" class="active">
                </li>
                <li data-slide-to="2" data-target="#carousel-916956">
                </li>
            </ol>
            <div class="carousel-inner">
                <div class="carousel-item">
                    <a href="fifa19.php">
                        <img class="d-block w-100" alt="Carousel Bootstrap First" src="fifa19.jpeg" />
                    </a>

                </div>
                <div class="carousel-item active">
                    <a href="cod.php">
                    <img class="d-block w-100" alt="Carousel Bootstrap Second" src="cod.jpeg" />
                    </a>

                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" alt="Carousel Bootstrap Third" src="spider.jpeg" />

                </div>
            </div> <a class="carousel-control-prev" href="#carousel-916956" data-slide="prev"><span class="carousel-control-prev-icon"></span>
                <span class="sr-only">Previous</span></a> <a class="carousel-control-next" href="#carousel-916956"
                data-slide="next"><span class="carousel-control-next-icon"></span> <span class="sr-only">Next</span></a>
        </div>
    </div>
</div>
<br>
<br>
<br>
<!-- game list -->
<div class="row">
    <div class="col-md-4">
        <img alt="Bootstrap Image Preview" src="fifa192.jpg" />
        <a href="fifa19.php">FIFA19</a>
    </div>
    <div class="col-md-4">
        <img alt="Bootstrap Image Preview" src="cod2.jpeg" />
        <a href="cod.php">Call of duty WW2</a>
    </div>
    <div class="col-md-4">
        <img alt="Bootstrap Image Preview" src="msw.jpeg" />
        <a href="">Shadow Of War</a>
    </div>
</div>
<br>
<br>

<div class="row">
    <div class="col-md-4">
        <img alt="" src="tomraider.jpeg" />
        <a href="">Tom Raider</a>
    </div>
    <div class="col-md-4">
        <img alt="" src="ass.jpeg" />
        <a href="">Assassin's Creed Syndicate</a>
    </div>
    <div class="col-md-4">
        <img alt="Bootstrap Image Preview" src="pes.jpeg" />
        <a href="">PES2019</a>
    </div>
</div>
<br>
<br>
<br>
<div class="row">
    <div class="col-md-12">
        <nav>
            <ul class="pagination">
                <li class="page-item">
                    <a class="page-link" href="#">Previous</a>
                </li>
                <li class="page-item">
                    <a class="page-link" href="index.php">1</a>
                </li>
                <li class="page-item">
                    <a class="page-link" href="#">2</a>
                </li>
                <li class="page-item">
                    <a class="page-link" href="#">3</a>
                </li>
                <li class="page-item">
                    <a class="page-link" href="#">4</a>
                </li>
                <li class="page-item">
                    <a class="page-link" href="#">5</a>
                </li>
                <li class="page-item">
                    <a class="page-link" href="#">Next</a>
                </li>
            </ul>
        </nav>
        <hr>
        <div>
            <div class="row">
                <div class="col-md-12">

                    <address>
                        <strong>Facebook, Inc. Đặng Khải Nguyễn Huy Đạt</strong><br /> Đại học Thuỷ Lợi, Tây Sơn<br />
                        Quận Đống Đa, Thành phố Hà Nội<br /> <abbr title="Phone">Phone:</abbr> 0948434818
                    </address>
                </div>
            </div>
        </div>
    </div>


    </body>

    </html>