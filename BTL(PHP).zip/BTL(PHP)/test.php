<?php
    // $_SERVER[‘PHP_SELF’]	Trả về tên file của file đang được chạy.

    // $_SERVER[‘SERVER_NAME’]	Trả về tên của máy chủ

    // $_SERVER[‘HTTP_HOST’]	Trả về tiêu đề chủ từ yêu cầu hiện tại
    echo $_SERVER['HTTP_HOST'];echo "<br>";

    // $_SERVER[‘SERVER_PORT’]	Trả về các cổng trên máy chủ được sử dụng bởi các máy chủ web để liên lạc(such as 80)
    echo $_SERVER['SERVER_PORT'];echo "<br>";

    // $_SERVER[‘SERVER_SIGNATURE’]	Trả về phiên bản máy chủ và tên máy chủ ảo được thêm vào các trang máy chủ tạo ra
    $a = "";
    $a = $_SERVER['SERVER_SIGNATURE'];
    echo gettype($a);echo "<br>";
    echo gettype($_SERVER['SERVER_SIGNATURE']);echo "<br>";

    // $_SERVER[‘SCRIPT_NAME’]	Trả về đường dẫn của kịch bản hiện tại
    // echo $_SERVER['SCRIPT_NAME'];echo "<br>";


    // echo $_SERVER['REQUEST_URI'];echo "<br>";
?>