<?php 
require("header.php");
?>

<fieldset style="width:400px;height:120px;margin:200px auto 0px;">
    <form role="form" method="post" action="" autocomplete="off">
        <h2>Reset Password</h2>
        <p><a href='index.php'>Trở lại trang chủ</a></p>
        <div class="form-group">
            <input type="email" name="email" id="email" class="form-control input-lg" placeholder="Email" value=""
                tabindex="1">
        </div>

        <hr>
        <div class="row">
            <div class="col-xs-6 col-md-6"><input type="submit" name="submit" value="Sent Reset Link" class="btn btn-primary btn-block btn-lg"
                    tabindex="2"></div>
        </div>
    </form>
    <hr>
    <div>
        <div class="row">
            <div class="col-md-12">

                <address>
                    <strong>Facebook, Inc. Đặng Khải Nguyễn Huy Đạt</strong><br /> Đại học Thuỷ Lợi, Tây Sơn<br /> Quận
                    Đống Đa, Thành phố Hà Nội<br /> <abbr title="Phone">Phone:</abbr> 0948434818
                </address>
            </div>
        </div>
    </div>
</fieldset>
</div>
</div>
</div>
</body>

</html>