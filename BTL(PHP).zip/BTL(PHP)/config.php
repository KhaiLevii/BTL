<?php
    $host="localhost"; // Host name
    $username="root"; // Mysql username
    $password=""; // Mysql password
    $db_name="webcrackgame"; // Database name
    $conn = mysqli_connect("$host", "$username", "$password", "$db_name") or die("connect failed");
?>