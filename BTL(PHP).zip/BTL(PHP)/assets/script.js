$(document).ready(function(){
    $(".show-login-btn").click(function(){
        $(".login-box").toggleClass("showed");
    });

    $(".hide-login-btn").click(function(){
        $(".login-box").toggleClass("showed");
    });
});